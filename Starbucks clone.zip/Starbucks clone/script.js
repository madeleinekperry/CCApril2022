$(document).ready(function(){

   $(".strawberrythumb li").hover(function(){
       $(".matcha").css("display", "none");}, function(){
           $(".matcha").css("display", "flex");
        });
       });

    $(".forestthumb li").hover(function(){
        $(".matcha").css("display", "none");}, 
        function(){
            $(".matcha").css("display", "flex");
        });
    $(".strawberrythumb li").hover(function(){
        $(".strawberry").css("display", "flex");},
        function(){
            $(".strawberry").css("display", "none");
    });
    $(".forestthumb li").hover(function(){
        $(".forest").css("display", "flex");}),
        function(){$(".forest").css("display", "none")};